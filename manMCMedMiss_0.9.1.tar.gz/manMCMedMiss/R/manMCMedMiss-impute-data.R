#' Impute Data
#'
#' Generates `m` complete data sets using Markov chain Monte Carlo.
#' See the `norm2::mcmcNorm()` and `norm2::impNorm()` functions for `method = "norm"`
#'  and `mice::mice()` for `method = "mice"`
#'  for more details
#'
#' @param method Character string.
#'   If `method = "norm"`, use the `norm2` package.
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @references
#' Schafer, J. L. (1997).
#' *Analysis of incomplete multivariate data*.
#' London: Chapman & Hall/CRC Press.
#'
#' @return Returns a list of complete data sets.
#'
#' @inheritParams Template
#' @importFrom norm2 emNorm mcmcNorm impNorm
#' @export
#' @family Data Generation Functions
#' @keywords manMCMedMiss gendata impute
#' @examples
#' data_complete <- GenData(n = 25L, tauprime = 0, beta = 0.5, alpha = 0.5)
#' data_missing <- AmputeData(data_complete, mech = "MAR", prop = 0.30)
#' ImputeData(data_missing, m = 5L, method = "norm")
#' ImputeData(data_missing, m = 5L, method = "mice")
ImputeData <- function(data_missing,
                       m = 100L,
                       method = "norm",
                       verbose = FALSE) {
  if (method == "norm") {
    return(
      ImputeDataNorm(
        data_missing = data_missing,
        m = m,
        verbose = verbose
      )
    )
  }
  if (method == "mice") {
    return(
      ImputeDataMICE(
        data_missing = data_missing,
        m = m
      )
    )
  }
}

ImputeDataMICE <- function(data_missing,
                           m = 100L) {
  out <- unname(
    mice::complete(
      data = mice::mice(
        data = data_missing,
        m = m,
        print = FALSE
      ),
      action = "all",
      include = FALSE
    )
  )
  out <- lapply(
    X = out,
    FUN = function(x) {
      as.matrix(x)
    }
  )
  class(out) <- "list"
  out
}

ImputeDataNorm <- function(data_missing,
                           m = 100L,
                           verbose = FALSE) {
  # Note that the EM algorithm is used as starting values for mcmcNorm.
  # The main work horse of this function is mcmcNorm.
  if (verbose) {
    em <- norm2::emNorm(
      obj = data_missing
    )
  } else {
    quiet <- function(x) {
      tmp_folder <- file.path(
        tempdir(),
        paste(
          sample(
            c(
              letters,
              LETTERS
            ),
            size = 8,
            replace = TRUE
          ),
          collapse = ""
        )
      )
      dir.create(
        tmp_folder,
        showWarnings = FALSE,
        recursive = TRUE
      )
      sink(tempfile(tmpdir = tmp_folder))
      on.exit(
        sink(),
        add = TRUE
      )
      on.exit(
        unlink(
          tmp_folder,
          recursive = TRUE
        ),
        add = TRUE
      )
      invisible(force(x))
    }
    em <- quiet(
      norm2::emNorm(
        obj = data_missing
      )
    )
  }
  if (!em$converged) {
    if (verbose) {
      em <- norm2::emNorm(
        obj = em,
        iter.max = 10000
      )
    } else {
      em <- quiet(
        norm2::emNorm(
          obj = em,
          iter.max = 10000
        )
      )
    }
    if (!em$converged) {
      stop(
        "The EM algorithm did not converge."
      )
    }
  }
  lapply(
    X = 1:m,
    FUN = function(i,
                   mcmc) {
      norm2::impNorm(
        obj = mcmc
      )
    },
    mcmc = norm2::mcmcNorm(
      obj = em,
      iter.max = 10000
    )
  )
  # mcmc = norm2::mcmcNorm(
  #  obj = norm2::mcmcNorm(
  #    obj = em
  #  ),
  #  iter.max = 10000
  # )
}
