#' @param n Integer.
#'   Sample size.
#' @param tauprime Numeric.
#'   \eqn{\tau^{\prime}}, that is, the path from \eqn{X} to \eqn{Y}, adjusting for \eqn{M}.
#' @param beta Numeric.
#'   \eqn{\beta}, that is, the path from \eqn{M} to \eqn{Y}.
#' @param alpha Numeric.
#'   \eqn{\alpha}, that is, the path from \eqn{X} to \eqn{M}.
#' @param mu Numeric.
#'   Common mean for \eqn{X}, \eqn{M}, and \eqn{Y},
#'   that is, \eqn{\mu_{X} = \mu_{M} = \mu_{Y}}.
#' @param sigmasq Numeric.
#'   Common variance for \eqn{X}, \eqn{M}, and \eqn{Y},
#'   that is, \eqn{\sigma^{2}_{X} = \sigma^{2}_{M} = \sigma^{2}_{Y}}.
#' @param data Numeric matrix.
#'   Output of the `GenData` or `AmputeData` functions.
#' @param data_complete Numeric matrix.
#'   Output of the `GenData` function.
#' @param data_missing Numeric matrix.
#'   Output of the `AmputeData` function.
#' @param mech Missing data mechanism.
#' @param prop Proportion of missing data.
#' @param patterns Numeric matrix consisting of zeroes and ones.
#'   Each row in the matrix represent a missing data pattern
#'   where 0 indicates a missing observation.
#'   The default value is all possible missing data patterns
#'   for a data set with 3 columns.
#' @param m Positive integer.
#'   Number of imputations.
#' @param mplus_bin Character string.
#'   Path of Mplus binary.
#' @param fit_mi Object.
#'   Output of the `FitModelMI` function.
#' @param fit_ml Object.
#'   Output of the `FitModelMI` function..
#' @param alpha Numeric vector.
#'   Significance level.
#' @param R Positive integer.
#'   Number of Monte Carlo replications.
#' @param B Positive integer.
#'   Number of bootstrap samples.
#' @param taskid Positive integer.
#'   Task ID.
#' @param repid Positive integer.
#'   Replication ID.
#' @param tasks Positive integer.
#'   Number of simulations tasks or cases.
#' @param reps Positive integer.
#'   Number of replications.
#' @param taskids Vector of taskids.
#' @param repids Vector of repids.
#' @param output_folder Character string.
#'   Output folder.
#' @param data_raw_folder Character string.
#'   `data-raw` folder in the project directory.
#' @param seed Integer.
#'   Random seed.
#' @param suffix Character string.
#'   Output of `.SimSeed`.
#' @param overwrite Logical.
#'   Overwrite existing output in `output_folder`.
#' @param params_taskid Data frame with a single row.
#'   Simulation parameters for a specific `taskid`.
#' @param params Data frame.
#'   Simulation parameters for all simulation tasks or cases.
#' @param data_type Character string.
#'   Input data type.
#'   Valid values include
#'   `"complete-00"`,
#'   `"mar-30"`,
#'   `"mar-20"`,
#'   `"mar-10"`,
#'   `"mcar-30"`,
#'   `"mcar-20"`, and
#'   `"mcar-10"`
#' @param output_type Character string.
#'   Output type.
#'   Valid values include
#'   `"data"`,
#'   `"fit-mi"`,
#'   `"fit-ml"`,
#'   `"mc-mi"`,
#'   `"mc-ml"`,
#'   `"nl-ml"`,
#'   `"sig-mi"`, and
#'   `"sig-ml"`.
#' @param summary_output Numeric matrix.
#'   Output of `Sum*` functions.
#' @param verbose Logical.
#'   If `verbose = TRUE`, print messages.
#'   If `verbose = FALSE`, suppress messages.
#'
#' @name Template
NULL
