#' Fit the Simple Mediation Model using Multiple Imputation
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns a list with the following elements:
#' \describe{
#'   \item{coef}{
#'     Pooled coefficients/parameter estimates
#'   }
#'   \item{vcov}{
#'     Total covariance matrix.
#'   }
#'   \item{vcov_tilde}{
#'     Adjusted total covariance matrix.
#'   }
#'   \item{vcov_between}{
#'     Covariance between imputations.
#'   }
#'   \item{vcov_within}{
#'     Covariance within imputations.
#'   }
#'   \item{ariv}{
#'     Average relative increase in variance.
#'   }
#'   \item{m}{
#'     Number of imputations.
#'   }
#'   \item{k}{
#'     Number of parameters.
#'   }
#'   \item{nu1}{
#'     Numerator degrees of freedom \eqn{\nu_1} for \eqn{D_1}.
#'   }
#'   \item{nu2}{
#'     Denominator degrees of freedom \eqn{\nu_2} for \eqn{D_1}.
#'   }
#'   \item{d1}{
#'     \eqn{D_1} test statistic.
#'   }
#' }
#'
#' @inheritParams Template
#' @export
#' @family Model Fitting Functions
#' @keywords manMCMedMiss fit mediation mi
FitModelMI <- function(data_missing,
                       m = 100L,
                       mplus_bin,
                       verbose = FALSE) {
  data <- ImputeData(
    data_missing = data_missing,
    m = m,
    method = "norm",
    verbose = verbose
  )
  fit <- lapply(
    X = data,
    FUN = FitModelML,
    mplus_bin = mplus_bin
  )
  coefs <- lapply(
    X = fit,
    FUN = function(i) {
      i$coef
    }
  )
  coef <- (
    1 / m
  ) * Reduce(
    f = `+`,
    x = coefs
  )
  vcov_within <- (
    1 / m
  ) * Reduce(
    f = `+`,
    x = lapply(
      X = fit,
      FUN = function(i) {
        i$vcov
      }
    )
  )
  vcov_between <- (
    1 / (
      m - 1
    )
  ) * Reduce(
    f = `+`,
    x = lapply(
      X = coefs,
      FUN = function(i, coef) {
        tcrossprod(i - coef)
      },
      coef = coef
    )
  )
  # total parameter covariance matrix
  vcov <- vcov_within + vcov_between + (1 / m) * vcov_between
  # average relative increase in variance
  # Li, Raghunathan, and Rubin (1991)
  k <- length(coef)
  ariv <- (
    1 + (
      1 / m
    ) * sum(
      diag(
        vcov_between %*% solve(
          vcov_within
        )
      )
    )
  ) / k
  vcov_tilde <- (1 + ariv) * vcov_within
  # d1 denominator degrees of freedom
  kmmk <- k * m - k
  if (kmmk <= 4) {
    nu2 <- (
      kmmk * (
        1 + (
          1 / k
        )
      ) * (
        1 + (
          1 / ariv
        )
      )^2
    ) / 2
  } else {
    nu2 <- 4 + (
      kmmk - 4
    ) * (
      1 + (
        1 - (
          2 / kmmk
        )
      ) * (
        1 / ariv
      )
    )^2
  }
  d1 <- drop(
    (
      1 / k
    ) * crossprod(
      coef,
      chol2inv(
        chol(vcov_tilde)
      )
    ) %*% coef
  )
  list(
    coef = coef,
    vcov = vcov,
    vcov_tilde = vcov_tilde,
    vcov_between = vcov_between,
    vcov_within = vcov_within,
    ariv = ariv,
    m = m,
    k = k,
    nu1 = k,
    nu2 = nu2,
    d1 = d1
  )
}
