#' @author Ivan Jacob Agaloos Pesigan
#'
#' @title manMCMedMiss:
#'   Monte Carlo Confidence Intervals for the Indirect Effect with Missing Data
#'
#' @description A collection of functions used in the manuscript
#'   Monte Carlo Confidence Intervals for the Indirect Effect with Missing Data
#'
#' @docType package
#' @name manMCMedMiss
#' @keywords manMCMedMiss package
NULL
