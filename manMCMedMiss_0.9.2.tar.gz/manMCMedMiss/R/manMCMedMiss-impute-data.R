#' Impute Data
#'
#' Generates `m` complete data sets using multiple imputation.
#' See the `norm2::mcmcNorm()` and `norm2::impNorm()` functions for `mi_method = "norm"`
#'  and `mice::mice()` for `mi_method = "mice"`
#'  for more details.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @references
#' Schafer, J. L. (1997).
#' *Analysis of incomplete multivariate data*.
#' London: Chapman & Hall/CRC Press.
#'
#' van Buuren, S., Groothuis-Oudshoorn, K. (2011).
#' mice: Multivariate imputation by chained equations in R.
#' *Journal of Statistical Software*,
#' *45*(3), 1–-67.
#' https://doi.org/10.18637/jss.v045.i03
#'
#' @return Returns a list of complete data sets.
#'
#' @inheritParams Template
#' @export
#' @family Data Generation Functions
#' @keywords manMCMedMiss gendata impute
#' @examples
#' data_complete <- GenData(n = 25L, tauprime = 0, beta = 0.5, alpha = 0.5)
#' data_missing <- AmputeData(data_complete, mech = "MAR", prop = 0.30)
#' ImputeData(data_missing, m = 5L, mi_method = "norm")
#' ImputeData(data_missing, m = 5L, mi_method = "mice")
ImputeData <- function(data_missing,
                       m = 100L,
                       mi_method = "norm",
                       verbose = FALSE) {
  if (mi_method == "norm") {
    return(
      ImputeDataNorm(
        data_missing = data_missing,
        m = m,
        verbose = verbose
      )
    )
  }
  if (mi_method == "mice") {
    return(
      ImputeDataMICE(
        data_missing = data_missing,
        m = m
      )
    )
  }
}
