#' Impute Data (`mi_method = "mice"`)
#'
#' Generates `m` complete data sets using multiple imputation by chained equations.
#' See `mice::mice()` for more details
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @references
#' van Buuren, S., Groothuis-Oudshoorn, K. (2011).
#' mice: Multivariate imputation by chained equations in R.
#' *Journal of Statistical Software*,
#' *45*(3), 1–-67.
#' https://doi.org/10.18637/jss.v045.i03
#'
#' @return Returns a list of complete data sets.
#'
#' @inheritParams Template
#' @importFrom mice mice
#' @export
#' @family Data Generation Functions
#' @keywords manMCMedMiss gendata impute
#' @examples
#' data_complete <- GenData(n = 25L, tauprime = 0, beta = 0.5, alpha = 0.5)
#' data_missing <- AmputeData(data_complete, mech = "MAR", prop = 0.30)
#' ImputeDataMICE(data_missing, m = 5L)
ImputeDataMICE <- function(data_missing,
                           m = 100L,
                           verbose = FALSE) {
  out <- unname(
    mice::complete(
      data = mice::mice(
        data = data_missing,
        m = m,
        print = verbose
      ),
      action = "all",
      include = FALSE
    )
  )
  out <- lapply(
    X = out,
    FUN = function(x) {
      as.matrix(x)
    }
  )
  class(out) <- "list"
  return(out)
}
