#' Simulation Replication
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return The output as saved as an external file in `output_folder`.
#'
#' @inheritParams Template
#' @export
#' @family Simulation Functions
#' @keywords manMCMedMiss simulation
Sim <- function(taskid,
                repid,
                output_folder,
                overwrite,
                params_taskid,
                alpha,
                m,
                R,
                B,
                mplus_bin,
                verbose) {
  # Do not include default arguments here.
  # All arguments should be set in `sim/sim-args.R`.
  # Add taskid to output_folder
  output_folder <- file.path(
    output_folder,
    paste0(
      SimProj(),
      "-",
      sprintf(
        "%05d",
        taskid
      )
    )
  )
  dir.create(
    path = output_folder,
    showWarnings = FALSE,
    recursive = TRUE
  )
  seed <- .SimSeed(
    taskid = taskid,
    repid = repid
  )
  # reseed for replications with errors ----------------------------------------
  if (repid == 42 & taskid == 144) {
    seed <- as.integer(seed * -1L)
  }
  # ----------------------------------------------------------------------------
  suffix <- .SimSuffix(
    taskid = taskid,
    repid = repid
  )
  SimGenData(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    params_taskid = params_taskid,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite
  )
  SimAmputeData(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite
  )
  SimFitModelML(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite,
    mplus_bin = mplus_bin
  )
  SimFitModelMI(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite,
    m = m,
    mplus_bin = mplus_bin,
    verbose = verbose
  )
  SimJointSigML(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite,
    alpha = alpha
  )
  SimJointSigMI(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite,
    alpha = alpha
  )
  SimMCML(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite,
    R = R,
    alpha = alpha
  )
  SimMCMI(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite,
    R = R,
    alpha = alpha
  )
  SimNBML(
    taskid = taskid,
    repid = repid,
    output_folder = output_folder,
    seed = seed,
    suffix = suffix,
    overwrite = overwrite,
    B = B,
    mplus_bin = mplus_bin
  )
  # SimNBMI(
  #  taskid = taskid,
  #  repid = repid,
  #  output_folder = output_folder,
  #  seed = seed,
  #  suffix = suffix,
  #  overwrite = overwrite,
  #  B = B,
  #  m = m,
  #  alpha = alpha
  # )
}
