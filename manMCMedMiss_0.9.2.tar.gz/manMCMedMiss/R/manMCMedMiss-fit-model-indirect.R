#' Fit the Simple Mediation Model using Normal Theory Maximum Likelihood (Indirect Effect)
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns the indirect effect.
#'
#' @inheritParams Template
#' @export
#' @family Model Fitting Functions
#' @keywords manMCMedMiss fit mediation ml
FitModelIndirect <- function(data_complete,
                             consistent = TRUE) {
  stopifnot(!any(is.na(data_complete))) # assert complete data
  cov_mat <- stats::cov(data_complete)
  if (consistent) {
    n <- nrow(data_complete)
    cov_mat <- (
      n / (n - 1)
    ) * cov_mat
  }
  return(
    (
      cov_mat["x", "m"] / cov_mat["x", "x"]
    ) * (
      (
        cov_mat["x", "x"] * cov_mat["m", "y"] - cov_mat["x", "m"] * cov_mat["x", "y"]
      ) / (
        cov_mat["x", "x"] * cov_mat["m", "m"] - cov_mat["x", "m"]^2
      )
    )
  )
}
