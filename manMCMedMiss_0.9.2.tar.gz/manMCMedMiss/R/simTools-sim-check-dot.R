#' Sanity Check to Determine Decision to Run Simulation
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns logical.
#' @param fn Complete file name and path of simulation output file.
#' @param overwrite Logical.
#'   Overwrite existing output in `output_folder`.
#' @keywords internal
.SimCheck <- function(fn,
                      overwrite) {
  if (overwrite) {
    return(TRUE)
  } else {
    if (file.exists(fn)) {
      tryCatch(
        {
          x <- readRDS(file = fn)
          rm(x)
          return(FALSE)
        },
        warning = function(w) {
          return(TRUE)
        },
        error = function(e) {
          return(TRUE)
        }
      )
    } else {
      return(TRUE)
    }
  }
}
