#' Summarize Simulations
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return The output is saved as an external file in `output_folder`.
#'
#' @inheritParams Template
#' @export
#' @family Summary Functions
#' @keywords manMCMedMiss summary
Sum <- function(taskid,
                reps,
                output_folder,
                params_taskid) {
  output_folder <- file.path(
    output_folder,
    paste0(
      SimProj(),
      "-",
      sprintf(
        "%05d",
        taskid
      )
    )
  )
  dir.create(
    path = output_folder,
    showWarnings = FALSE,
    recursive = TRUE
  )
  con <- xzfile(
    description = file.path(
      output_folder,
      paste0(
        SimProj(),
        "-",
        .SimSuffix(
          taskid = taskid,
          repid = NULL
        )
      )
    ),
    compression = 9L
  )
  saveRDS(
    object = list(
      sig_mi <- SumJointSigMI(
        taskid = taskid,
        reps = reps,
        output_folder = output_folder,
        params_taskid = params_taskid
      ),
      sig_ml <- SumJointSigML(
        taskid = taskid,
        reps = reps,
        output_folder = output_folder,
        params_taskid = params_taskid
      ),
      mc_mi <- SumMCMI(
        taskid = taskid,
        reps = reps,
        output_folder = output_folder,
        params_taskid = params_taskid
      ),
      mc_ml <- SumMCML(
        taskid = taskid,
        reps = reps,
        output_folder = output_folder,
        params_taskid = params_taskid
      ),
      nb_ml = SumNBML(
        taskid = taskid,
        reps = reps,
        output_folder = output_folder,
        params_taskid = params_taskid
      )
      # ,
      # nb_mi = SumNBMI(
      #  taskid = taskid,
      #  reps = reps,
      #  output_folder = output_folder,
      #  params_taskid = params_taskid
      # )
    ),
    file = con
  )
  close(con)
}
