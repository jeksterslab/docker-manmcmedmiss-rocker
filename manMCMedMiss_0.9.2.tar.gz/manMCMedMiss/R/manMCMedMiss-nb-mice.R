#' Nonparametric Bootstrap Confidence Intervals for the Indirect Effect using Multiple Imputation with Chained Equations (MI nested within NB)
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Nonparametric bootstrap percentile confidence intervals.
#'
#' @references
#' Zhang, Z., & Wang, L. (2012).
#' Methods for mediation analysis with missing data.
#' *Psychometrika*, *78*(1), 154–184.
#' \doi{10.1007/s11336-012-9301-5}
#'
#' Zhang, Z., Wang, L., & Tong, X. (2015).
#' Mediation analysis with missing data through multiple imputation and bootstrap.
#' *Quantitative psychology research* (pp. 341–355).
#' Springer International Publishing.
#' \doi{10.1007/978-3-319-19977-1_24}
#'
#' @inheritParams Template
#' @export
#' @family Confidence Interval Functions
#' @keywords manMCMedMiss ci mediation mi
NBMICE <- function(data_missing,
                   B = 5000L,
                   m = 100L,
                   alpha = c(0.05, 0.01, 0.001),
                   mplus_bin,
                   verbose = FALSE) {
  thetahatstar <- sapply(
    X = 1:B,
    FUN = function(b,
                   data_missing,
                   n,
                   m,
                   mplus_bin) {
      coefs <- FitModelMICE(
        data_missing = data_missing[
          sample.int(
            n = n,
            size = n,
            replace = TRUE
          ),
        ],
        m = m,
        mplus_bin = mplus_bin,
        verbose = verbose
      )$coef
      coefs[4] * coefs[5]
    },
    data_missing = data_missing,
    n = dim(data_missing)[1],
    m = m,
    mplus_bin = mplus_bin
  )
  stats::quantile(
    thetahatstar,
    probs = .ProbsofAlpha(alpha = alpha)
  )
}
